﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZH1_SSFADL
{
    
    internal class Sor
    {
        public int Szám { get; set; }
        public int Fibo { get; set; }
    }
}
